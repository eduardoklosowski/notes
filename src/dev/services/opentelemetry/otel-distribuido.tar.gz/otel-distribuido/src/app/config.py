APP1_URL = 'http://localhost:8001/'
APP2_URL = 'http://localhost:8002/'
QUEUE_NAME = 'my-queue'
