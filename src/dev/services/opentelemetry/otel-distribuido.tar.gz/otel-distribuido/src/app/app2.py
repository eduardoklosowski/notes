import asyncio
import boto3
import logging
from fastapi import FastAPI
from http import HTTPStatus
from opentelemetry import trace
from pydantic import BaseModel
from random import randint

from .config import QUEUE_NAME
from .models import CalcRequestMessage, Operation

log = logging.getLogger(__name__)
tracer = trace.get_tracer(__name__)


@tracer.start_as_current_span('send_message')
def send_message(*, queue_name: str, message: BaseModel) -> None:
    message_json = message.model_dump_json()
    span = trace.get_current_span()
    span.set_attributes({
        'queue_name': queue_name,
        'message': message_json,
    })
    log.info('Sending message...')

    with tracer.start_as_current_span('send_message.connecting_aws'):
        log.info('Connectiong aws...')
        client = boto3.client('sqs')

    with tracer.start_as_current_span('send_message.get_queue_url'):
        log.info('Getting queue url...')
        queue_url = client.get_queue_url(QueueName=queue_name)['QueueUrl']

    with tracer.start_as_current_span('send_message.send_message_to_queue'):
        log.info('Sending to queue...')
        client.send_message(
            QueueUrl=queue_url,
            MessageBody=message_json,
        )


app = FastAPI(title='app2')


class CalcRequest(BaseModel):
    operation: Operation
    value1: int
    value2: int


class CalcResponse(BaseModel):
    id: int


@app.post('/calc', status_code=HTTPStatus.ACCEPTED)
async def calc_endpoint(body: CalcRequest) -> CalcResponse:
    id = randint(1, 2**16)
    trace.get_current_span().set_attribute('id', id)
    log.info('Receiving calc request %r', id)

    with tracer.start_as_current_span('calc_endpoint.sending_message'):
        log.info('Sending calc %r to queue', id)
        asyncio.create_task(asyncio.to_thread(
            send_message,
            queue_name=QUEUE_NAME,
            message=CalcRequestMessage(
                id=id,
                operation=body.operation,
                value1=body.value1,
                value2=body.value2,
            ),
        ))

    log.info('Responsing calc id %r', id)
    return CalcResponse(id=id)
