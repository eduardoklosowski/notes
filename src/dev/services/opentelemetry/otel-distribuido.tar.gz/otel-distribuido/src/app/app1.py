import asyncio
import httpx
import logging
from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import PlainTextResponse
from opentelemetry import trace
from http import HTTPStatus
from typing import Annotated

from .config import APP2_URL
from .models import Operation

log = logging.getLogger(__name__)
tracer = trace.get_tracer(__name__)

CALCS: dict[int, asyncio.Future[str]] = {}

app = FastAPI(title='app1')


@app.get('/{op}/{v1}/{v2}', response_class=PlainTextResponse)
async def calc_endpoint(op: Operation, v1: int, v2: int) -> str:
    span = trace.get_current_span()
    log.info('Receive calc request')

    result = asyncio.Future()
    with tracer.start_as_current_span('calc_endpoint.calling_calc_api'):
        log.info('Calling calc API')
        async with httpx.AsyncClient(base_url=APP2_URL) as client:
            response = await client.post(
                '/calc',
                json={
                    'operation': op,
                    'value1': v1,
                    'value2': v2,
                },
            )
            response.raise_for_status()
            id = response.json()['id']
            CALCS[id] = result
        span.set_attribute('id', id)
        log.info('Calc id received (%r)', id)

    with tracer.start_as_current_span('calc_endpoint.waiting_result'):
        log.info('Waiting result of %r calc...', id)
        response = await result

    log.info('Responding calc %r', id)
    return response


@app.post('/result/{id}', status_code=HTTPStatus.NO_CONTENT)
async def result_endpoint(id: int, body: Annotated[str, Body(media_type='text/plain')]) -> None:
    log.info('Receiving response of %r', id)
    with tracer.start_as_current_span('result_endpoint.set_result'):
        try:
            CALCS.pop(id).set_result(body)
        except KeyError:
            raise HTTPException(HTTPStatus.NOT_FOUND)
