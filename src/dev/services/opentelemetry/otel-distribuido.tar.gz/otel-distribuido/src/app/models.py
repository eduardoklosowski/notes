from enum import Enum
from pydantic import BaseModel


class Operation(str, Enum):
    ADDICTION = '+'
    SUBTRACTION = '-'
    MULTIPLICATION = '*'
    DIVISION = '%'


class CalcRequestMessage(BaseModel):
    id: int
    operation: Operation
    value1: int
    value2: int
