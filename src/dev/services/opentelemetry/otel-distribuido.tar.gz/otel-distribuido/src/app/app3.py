import boto3
import httpx
import logging
from collections.abc import Generator
from contextlib import suppress
from opentelemetry import trace
from opentelemetry.propagate import extract
from typing import TYPE_CHECKING, assert_never
from urllib.parse import quote as url_quote

from .config import APP1_URL, QUEUE_NAME
from .models import CalcRequestMessage, Operation

if TYPE_CHECKING:
    from types_boto3_sqs import SQSClient
    from types_boto3_sqs.type_defs import MessageTypeDef

log = logging.getLogger('app.app3')
tracer = trace.get_tracer('app.app3')


@tracer.start_as_current_span('get_queue_url')
def get_queue_url(*, client: SQSClient, queue_name: str) -> str:
    trace.get_current_span().set_attribute('queue_name', queue_name)
    log.info('Getting url of queue %r', queue_name)
    return client.get_queue_url(QueueName=queue_name)['QueueUrl']


@tracer.start_as_current_span('listener_messages')
def listener_messages(*, client: SQSClient, queue_url: str) -> Generator[MessageTypeDef]:
    trace.get_current_span().set_attribute('queue_url', queue_url)
    log.info('Listening messages from queue...')
    while True:
        messages = client.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=10,
            WaitTimeSeconds=20,
            MessageAttributeNames=['All'],
        )
        for message in messages.get('Messages', []):
            log.info('Received a message')
            yield message
            log.info('Removing message from queue')
            client.delete_message(
                QueueUrl=queue_url,
                ReceiptHandle=message['ReceiptHandle'],
            )


@tracer.start_as_current_span('calc')
def calc(*, operation: Operation, value1: int, value2: int) -> int:
    span = trace.get_current_span()
    span.set_attributes({
        'operation': operation,
        'value1': value1,
        'value2': value2,
    })
    log.info('Calc operation %r with %r and %r', operation.value, value1, value2)

    match operation:
        case Operation.ADDICTION:
            result = value1 + value2
        case Operation.SUBTRACTION:
            result = value1 - value2
        case Operation.MULTIPLICATION:
            result = value1 * value2
        case Operation.DIVISION:
            result = value1 // value2
        case _ as unreachable:
            assert_never(unreachable)
    span.set_attribute('result', result)
    log.info('Result is %r', result)
    return result


@tracer.start_as_current_span('MainProcess')
def main() -> None:
    log.info('Connecting AWS...')
    client = boto3.client('sqs')

    queue_url = get_queue_url(client=client, queue_name=QUEUE_NAME)
    for message in listener_messages(client=client, queue_url=queue_url):
        carrier = {k: v['StringValue'] for k, v in message.get('MessageAttributes', {}).items() if 'StringValue' in v}
        with tracer.start_as_current_span('MessageReceived', context=extract(carrier)):
            calc_request = CalcRequestMessage.model_validate_json(message['Body'])

            with tracer.start_as_current_span('MainProcess.calc'):
                result = calc(
                    operation=calc_request.operation,
                    value1=calc_request.value1,
                    value2=calc_request.value2,
                )
                response = f'{calc_request.value1} {calc_request.operation.value} {calc_request.value2} = {result}'

            with tracer.start_as_current_span('MainProcess.return_result'), httpx.Client(base_url=APP1_URL) as app1:
                app1.post(
                    f'/result/{url_quote(str(calc_request.id))}',
                    data=response,
                )


if __name__ == '__main__':
    with suppress(KeyboardInterrupt):
        main()
