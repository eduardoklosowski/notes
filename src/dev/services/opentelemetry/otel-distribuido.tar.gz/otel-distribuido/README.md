# OpenTelemetry Propagation - Trace Distribuído

Esse projeto demonstra o [trace distribuído com OpenTelemetry](https://opentelemetry.io/docs/languages/python/propagation/) entre sistemas que se comunicam através de chamadas [HTTP](https://pt.wikipedia.org/wiki/HTTP) ([API REST](https://pt.wikipedia.org/wiki/REST)) e mensagens em filas [Amazon SQS](https://aws.amazon.com/pt/sqs/).

O sistema consiste em uma API disponibilizada para o usuário realizar cálculos matemáticos:

```txt
$ http GET http://localhost:8001/+/1/1
HTTP/1.1 200 OK
content-length: 9
content-type: text/plain; charset=utf-8
date: Fri, 27 Feb 2026 01:23:41 GMT
server: uvicorn

1 + 1 = 2
```

O funcionamento do sistema ocorre da seguinte forma:

1. O usuário informa o cálculo a ser feito através de requisições HTTP para a App 1.
2. A App 1 faz uma requisição HTTP para a App 2, que devolve um identificador (id) para o cálculo. A App 1 fica aguardando até receber uma resposta com esse id.
3. A App 2 envia uma mensagem para a fila SQS com o cálculo a ser feito.
4. A App 3 consome as mensagens da fila, realiza o cálculo e reporta o resultado para a App 1 usando o id do cálculo.
5. A App 1 responde o resultado do cálculo para o usuário.

```mermaid
flowchart TD
    user[Usuário]
    app1[App 1]
    app2[App 2]
    app3[App 3]
    sqs[&lt;&lt;Fila SQS&gt;&gt;<br>my-queue]
    user -->|Envia cálculo| app1 -->|Requisição HTTP| app2 -->|Devolve id do cálculo| app1
    app2 -->|Envia mensagem para fila SQS| sqs -->|Consome mensagem da fila SQS| app3 -->|Reporta resultado do cálculo| app1
    app1 -->|Responde resultado da conta| user
```

## Execução do Sistema

Para facilitar a execução, esse projeto pode ser aberto em um [Dev Container](https://containers.dev/) que já instalará dentro de um contêiner todas as ferramentas necessárias. Isso pode ser feito no [Visual Studio Code](https://code.visualstudio.com/) com o plugin [Dev Containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers). Ou no [IntelliJ IDEA](https://www.jetbrains.com/pt-br/idea/download/) (uma assinatura Ultimate pode ser necessária).

Para executar o sistema, primeiro verifique que as dependências estão rodando com:
```sh
docker compose up -d
docker compose ps -a
```

Depois execute as aplicações App1, App2 e App3, cada uma em um terminal:
```sh
make run-app1
```
```sh
make run-app2
```
```sh
make run-app3
```

Após isso requisições podem ser feitas para `http://localhost:8001/{operação}/{valor1}/{valor2}`. Sendo `{operação}` qualquer umas das operações matemáticas a baixo. `{valor1}` e `{valor2}` são números inteiros.

| `{operação}` | Função Matemática |
| ------------ | ----------------- |
| `+`          | Adição            |
| `-`          | Subtração         |
| `*`          | Multiplicação     |
| `%`          | Divisão           |

Exemplo somando os valores `10` e `20`:
```txt
http://localhost:8001/+/10/20
```

## Monitoramento

O monitoramento e acompanhamento das execução podem ser realizadas através do [Grafana](https://grafana.com/) incluso no projeto. Ele é iniciado através do [docker compose](https://docs.docker.com/compose/) e está disponível em http://localhost:3000/.

Exemplo de visualização do trace desde a requisição do usuário até sua resposta, passando pelas aplicações App 1, App 2 e App 3:
![trace](trace.png)

Exemplo de visualização do log de todas as aplicações relativos a uma requisição do usuário:
![log](log.png)
