#!/bin/bash

set -xe

# configure httpie
pipx install httpie==3.2.4

# Configure aws
mkdir -p /tmp/aws
pushd /tmp/aws
wget -O awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64-2.33.30.zip
unzip -q awscliv2.zip
sudo ./aws/install
popd
rm -rf /tmp/aws
sudo bash -c 'echo "complete -C \"$(which aws_completer)\" aws" > /etc/bash_completion.d/aws'

# Init project
make init
