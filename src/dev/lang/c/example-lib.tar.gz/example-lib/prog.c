#include <stdio.h>
#include "conta.h"

int main() {
    int valor = soma(2, 3);
    printf("%d\n", valor);
    return 0;
}
