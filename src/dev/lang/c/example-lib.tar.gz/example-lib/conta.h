#ifndef LIB_CONTA_INCLUDED
#define LIB_CONTA_INCLUDED

int soma(int a, int b);

#endif
