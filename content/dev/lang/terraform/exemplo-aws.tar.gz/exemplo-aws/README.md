# Exemplo de Terraform com AWS

Esse é um exemplo de projeto utilizando [Terraform](https://www.terraform.io/) com [AWS](https://aws.amazon.com/pt/).

Mocks disponíveis:
- [Moto](https://docs.getmoto.org/)
- [LocalStack](https://docs.localstack.cloud/overview/)

## Executando o projeto

Esse projeto pode ser aberto com [DevContainer](https://containers.dev/). Após abrí-lo, é necessário executar um mock da AWS. Exemplo:

```sh
make run-localstack
```

Em seguida é possível executar comandos do Terraform. Exemplo:

```sh
make init
make plan
make apply
make destroy
```
