#!/bin/bash -xe

# AWS Config
mkdir -p ~/.aws
cat > ~/.aws/config <<EOF
[profile local]
region = us-east-1
endpoint_url = http://localhost:4566/
output = json
EOF
cat > ~/.aws/credentials <<EOF
[local]
aws_access_key_id = testing
aws_secret_access_key = testing
aws_session_token = testing
EOF
chmod 600 ~/.aws/config ~/.aws/credentials

# Completion
mkdir -p ~/.local/share/bash-completion/completions
echo 'eval "$(docker completion bash)"' > ~/.local/share/bash-completion/completions/docker
echo "complete -C \"$(which terraform)\" terraform" > ~/.local/share/bash-completion/completions/terraform
