from pika import BasicProperties, BlockingConnection, ConnectionParameters
from pika.channel import Channel
from pika.credentials import PlainCredentials
from pika.spec import Basic


def process_message(ch: Channel, method: Basic.Deliver, properties: BasicProperties, body: bytes):
    print(body.decode())
    ch.basic_ack(method.delivery_tag)


print('Conectando no RabbitMQ...')
parameters = ConnectionParameters(
    host='127.0.0.1',
    port=5672,
    credentials=PlainCredentials(
        username='guest',
        password='guest',
    ),
    virtual_host='/',
)
conn = BlockingConnection(parameters)
print('Abrindo canal...')
channel = conn.channel()
print('Lendo mensagens...')
channel.basic_consume(queue='queue', on_message_callback=process_message)
try:
    channel.start_consuming()
except KeyboardInterrupt:
    print('Fechando a conexão...')
    channel.stop_consuming()
channel.close()
conn.close()
