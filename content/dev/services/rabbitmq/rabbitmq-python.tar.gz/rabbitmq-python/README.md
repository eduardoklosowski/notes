# RabbitMQ em Python

Exemplo de código [Python](https://www.python.org/) com [RabbitMQ](https://www.rabbitmq.com/).

## Setup Inicial

O RabbitMQ pode ser iniciado através do [Docker Compose](https://docs.docker.com/compose/):

```sh
docker-compose up -d
```

No Python pode ser criado um [ambiente virtual](https://docs.python.org/pt-br/3/library/venv.html) para instalar as bibliotecas:

```sh
python3 -m venv env
./env/bin/pip install -r requirements.txt
```

Para criar os tópicos e filas utilizados nesse exemplo execute:

```sh
./env/bin/python setup-infra.py
```

## Implementações

O código pode ser executado com:

```sh
./env/bin/python <arquivo>
```

Sendo as implementações:

- Biblioteca oficial (versão bloqueante):
  - `setup-infra.py`: Cria tópicos, filas e faz o bind
  - `block-producer.py`: Produtor de mensagens
  - `block-consumer.py`: Consumidor de mensagens
  - `block-consumer-callback.py`: Consumidor de mensagens através de callback
- Biblioteca async:
  - `aio-producer.py`: Produtor de mensagens
  - `aio-consumer.py`: Consumidor de mensagens
  - `aio-consumer-callback.py`: Consumidor de mensagens através de callback

## Limpeza

Para remover o contêiner Docker e o ambiente virtual execute:

```sh
docker-compose down -v
rm -rf env
```
