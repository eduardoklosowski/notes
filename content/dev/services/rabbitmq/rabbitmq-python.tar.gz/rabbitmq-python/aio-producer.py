import asyncio

from aio_pika import DeliveryMode, Message, connect


async def main(loop):
    print('Conectando no RabbitMQ...')
    conn = await connect(
        host='127.0.0.1',
        port=5672,
        login='guest',
        password='guest',
        virtualhost='/',
        loop=loop,
    )
    async with conn:
        print('Abrindo canal...')
        channel = await conn.channel()
        while True:
            msg = input('Mensagem: ')
            if not msg:
                break
            topic = await channel.get_exchange(name='topic')
            await topic.publish(
                routing_key='',
                message=Message(
                    body=msg.encode(),
                    delivery_mode=DeliveryMode.PERSISTENT,
                ),
                mandatory=False,
            )
        print('Fechando a conexão...')

loop = asyncio.get_event_loop()
loop.run_until_complete(main(loop))
