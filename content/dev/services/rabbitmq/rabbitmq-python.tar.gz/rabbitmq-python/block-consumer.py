from pika import BlockingConnection, ConnectionParameters
from pika.credentials import PlainCredentials

print('Conectando no RabbitMQ...')
parameters = ConnectionParameters(
    host='127.0.0.1',
    port=5672,
    credentials=PlainCredentials(
        username='guest',
        password='guest',
    ),
    virtual_host='/',
)
conn = BlockingConnection(parameters)
print('Abrindo canal...')
channel = conn.channel()
print('Lendo mensagens...')
try:
    for method_frame, properties, body in channel.consume(queue='queue', auto_ack=False):
        print(body.decode())
        channel.basic_ack(method_frame.delivery_tag)
except KeyboardInterrupt:
    ...
channel.cancel()
print('Fechando a conexão...')
channel.close()
conn.close()
