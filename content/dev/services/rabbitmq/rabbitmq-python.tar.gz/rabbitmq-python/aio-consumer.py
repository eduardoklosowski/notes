import asyncio

from aio_pika import connect


async def main(loop):
    print('Conectando no RabbitMQ...')
    conn = await connect(
        host='127.0.0.1',
        port=5672,
        login='guest',
        password='guest',
        virtualhost='/',
        loop=loop,
    )
    async with conn:
        print('Abrindo canal...')
        channel = await conn.channel()
        print('Lendo mensagens...')
        queue = await channel.get_queue('queue')
        async with queue.iterator() as queue_iter:
            async for message in queue_iter:
                async with message.process():
                    print(message.body.decode())
        print('Fechando a conexão...')


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(main(loop))
    except KeyboardInterrupt:
        ...
