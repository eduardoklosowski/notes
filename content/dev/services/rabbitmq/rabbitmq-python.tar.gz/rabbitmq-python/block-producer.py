from pika import BasicProperties, BlockingConnection, ConnectionParameters
from pika.credentials import PlainCredentials
from pika.spec import PERSISTENT_DELIVERY_MODE

print('Conectando no RabbitMQ...')
parameters = ConnectionParameters(
    host='127.0.0.1',
    port=5672,
    credentials=PlainCredentials(
        username='guest',
        password='guest',
    ),
    virtual_host='/',
)
conn = BlockingConnection(parameters)
print('Abrindo canal...')
channel = conn.channel()
channel.confirm_delivery()
while True:
    msg = input('Mensagem: ')
    if not msg:
        break
    channel.basic_publish(
        exchange='topic',
        routing_key='',
        body=msg,
        properties=BasicProperties(delivery_mode=PERSISTENT_DELIVERY_MODE),
        mandatory=False,
    )
print('Fechando a conexão...')
channel.close()
conn.close()
