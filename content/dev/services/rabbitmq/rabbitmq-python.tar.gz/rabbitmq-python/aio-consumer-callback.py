import asyncio

from aio_pika import connect
from aio_pika.abc import AbstractIncomingMessage


async def process_message(message: AbstractIncomingMessage):
    async with message.process():
        print(message.body.decode())


async def main(loop):
    print('Conectando no RabbitMQ...')
    conn = await connect(
        host='127.0.0.1',
        port=5672,
        login='guest',
        password='guest',
        virtualhost='/',
        loop=loop,
    )
    async with conn:
        print('Abrindo canal...')
        channel = await conn.channel()
        print('Lendo mensagens...')
        queue = await channel.get_queue('queue')
        await queue.consume(process_message)
        await asyncio.Future()
        print('Fechando a conexão...')


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(main(loop))
    except KeyboardInterrupt:
        ...
