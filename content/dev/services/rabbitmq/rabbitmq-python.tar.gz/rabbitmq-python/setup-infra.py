from pika import BlockingConnection, ConnectionParameters
from pika.credentials import PlainCredentials

print('Conectando no RabbitMQ...')
parameters = ConnectionParameters(
    host='127.0.0.1',
    port=5672,
    credentials=PlainCredentials(
        username='guest',
        password='guest',
    ),
    virtual_host='/',
)
conn = BlockingConnection(parameters)
print('Abrindo canal...')
channel = conn.channel()
print('Criando tópico...')
channel.exchange_declare(exchange='topic', durable=True)
print('Criando fila...')
channel.queue_declare('queue', durable=True)
print('Fazendo bind do tópico para a fila...')
channel.queue_bind(queue='queue', exchange='topic', routing_key='')
print('Fechando a conexão...')
channel.close()
conn.close()
